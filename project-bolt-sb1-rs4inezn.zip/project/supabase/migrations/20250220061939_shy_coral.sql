/*
  # Fix RLS policies for items table

  1. Changes
    - Drop existing RLS policies for items table
    - Create new, more permissive policies for authenticated users

  2. Security
    - Enable RLS on items table
    - Add policies for authenticated users to perform all operations
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON items;
DROP POLICY IF EXISTS "Enable insert access for authenticated users" ON items;
DROP POLICY IF EXISTS "Enable delete access for authenticated users" ON items;

-- Create new policies
CREATE POLICY "Enable all access for authenticated users" ON items
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);