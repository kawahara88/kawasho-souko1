/*
  # Add Lot number to items and stock movements

  1. Changes
    - Add `lot_number` column to `items` table
    - Add `lot_number` column to `stock_movements` table
    - Update unique constraint on `items` table to include `lot_number`

  2. Security
    - No changes to RLS policies required
*/

-- Add lot_number column to items table
ALTER TABLE items
ADD COLUMN lot_number text DEFAULT NULL;

-- Add lot_number column to stock_movements table
ALTER TABLE stock_movements
ADD COLUMN lot_number text DEFAULT NULL;

-- Drop existing unique constraint
ALTER TABLE items
DROP CONSTRAINT items_name_color_size_key;

-- Add new unique constraint including lot_number
ALTER TABLE items
ADD CONSTRAINT items_name_color_size_lot_number_key 
UNIQUE (name, color, size, lot_number);