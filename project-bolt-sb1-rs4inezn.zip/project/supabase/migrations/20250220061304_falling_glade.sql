/*
  # Create Inventory Management Tables

  1. New Tables
    - `items`: Stores item information
      - `id` (uuid, primary key)
      - `name` (text)
      - `color` (text)
      - `size` (text)
      - `pieces_per_case` (integer)
      - `width` (numeric)
      - `depth` (numeric)
      - `height` (numeric)
      - `cubic_meters` (numeric)
      - `created_at` (timestamptz)

    - `stock_movements`: Records stock movements
      - `id` (uuid, primary key)
      - `item_id` (uuid, foreign key)
      - `movement_date` (date)
      - `movement_type` (text)
      - `quantity_type` (text)
      - `quantity` (integer)
      - `created_at` (timestamptz)

    - `stock`: Current stock levels
      - `id` (uuid, primary key)
      - `item_id` (uuid, foreign key)
      - `total_pieces` (integer)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create items table
CREATE TABLE items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  color text NOT NULL,
  size text NOT NULL,
  pieces_per_case integer NOT NULL,
  width numeric NOT NULL,
  depth numeric NOT NULL,
  height numeric NOT NULL,
  cubic_meters numeric NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(name, color, size)
);

-- Create stock_movements table
CREATE TABLE stock_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id uuid REFERENCES items(id) ON DELETE CASCADE,
  movement_date date NOT NULL,
  movement_type text NOT NULL CHECK (movement_type IN ('in', 'out')),
  quantity_type text NOT NULL CHECK (quantity_type IN ('case', 'piece')),
  quantity integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create stock table
CREATE TABLE stock (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id uuid REFERENCES items(id) ON DELETE CASCADE,
  total_pieces integer NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(item_id)
);

-- Enable RLS
ALTER TABLE items ENABLE ROW LEVEL SECURITY;
ALTER TABLE stock_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE stock ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for authenticated users" ON items
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable insert access for authenticated users" ON items
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Enable delete access for authenticated users" ON items
  FOR DELETE TO authenticated USING (true);

CREATE POLICY "Enable read access for authenticated users" ON stock_movements
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable insert access for authenticated users" ON stock_movements
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Enable read access for authenticated users" ON stock
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable all access for authenticated users" ON stock
  FOR ALL TO authenticated USING (true);