/*
  # Update stock movements RLS policies

  1. Changes
    - Drop existing policies on stock_movements table
    - Create new policies that properly handle soft delete functionality
    - Allow authenticated users to perform all operations
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON stock_movements;
DROP POLICY IF EXISTS "Enable insert access for authenticated users" ON stock_movements;
DROP POLICY IF EXISTS "Enable update for soft delete" ON stock_movements;

-- Create a single policy that allows all operations for authenticated users
CREATE POLICY "Enable all access for authenticated users" ON stock_movements
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);