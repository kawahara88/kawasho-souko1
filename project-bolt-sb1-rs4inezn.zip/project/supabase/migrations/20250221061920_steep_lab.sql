/*
  # Add storage fees functionality

  This migration adds storage fee tracking capabilities if they don't already exist.
  It safely checks for existing objects before creating them.

  1. Changes
    - Ensures storage_fees table exists with all required columns
    - Adds RLS policies if not present
*/

-- First check if the table exists, if not create it
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename = 'storage_fees'
  ) THEN
    CREATE TABLE storage_fees (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      item_id uuid REFERENCES items(id) ON DELETE CASCADE,
      period_start date NOT NULL,
      period_end date NOT NULL,
      cubic_meters numeric NOT NULL,
      storage_fee numeric NOT NULL,
      inbound_fee numeric NOT NULL,
      outbound_fee numeric NOT NULL,
      total_fee numeric NOT NULL,
      created_at timestamptz DEFAULT now()
    );

    -- Enable RLS
    ALTER TABLE storage_fees ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Safely create policies if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'storage_fees' 
    AND policyname = 'Enable read access for authenticated users'
  ) THEN
    CREATE POLICY "Enable read access for authenticated users" ON storage_fees
      FOR SELECT TO authenticated USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'storage_fees' 
    AND policyname = 'Enable insert access for authenticated users'
  ) THEN
    CREATE POLICY "Enable insert access for authenticated users" ON storage_fees
      FOR INSERT TO authenticated WITH CHECK (true);
  END IF;
END $$;