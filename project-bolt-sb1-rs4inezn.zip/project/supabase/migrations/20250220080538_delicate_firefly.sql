/*
  # Add storage fee system

  1. New Tables
    - `storage_fees`
      - `id` (uuid, primary key)
      - `item_id` (uuid, references items)
      - `period_start` (date)
      - `period_end` (date)
      - `cubic_meters` (numeric)
      - `storage_fee` (numeric)
      - `inbound_fee` (numeric)
      - `outbound_fee` (numeric)
      - `total_fee` (numeric)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on `storage_fees` table
    - Add policy for authenticated users to read their own data
*/

CREATE TABLE storage_fees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id uuid REFERENCES items(id) ON DELETE CASCADE,
  period_start date NOT NULL,
  period_end date NOT NULL,
  cubic_meters numeric NOT NULL,
  storage_fee numeric NOT NULL,
  inbound_fee numeric NOT NULL,
  outbound_fee numeric NOT NULL,
  total_fee numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE storage_fees ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Enable read access for authenticated users" ON storage_fees
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Enable insert access for authenticated users" ON storage_fees
  FOR INSERT TO authenticated WITH CHECK (true);