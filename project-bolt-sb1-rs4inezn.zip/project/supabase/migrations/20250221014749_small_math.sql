/*
  # Add deleted_at column to stock_movements table

  1. Changes
    - Add `deleted_at` timestamp column to `stock_movements` table for soft delete functionality
*/

ALTER TABLE stock_movements
ADD COLUMN deleted_at timestamptz DEFAULT NULL;

-- Update the select policy to exclude deleted records
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON stock_movements;
CREATE POLICY "Enable read access for authenticated users" ON stock_movements
  FOR SELECT TO authenticated
  USING (deleted_at IS NULL);

-- Update the insert policy to ensure deleted_at is NULL on insert
DROP POLICY IF EXISTS "Enable insert access for authenticated users" ON stock_movements;
CREATE POLICY "Enable insert access for authenticated users" ON stock_movements
  FOR INSERT TO authenticated
  WITH CHECK (deleted_at IS NULL);

-- Add update policy for soft delete
CREATE POLICY "Enable update for soft delete" ON stock_movements
  FOR UPDATE TO authenticated
  USING (true)
  WITH CHECK (true);