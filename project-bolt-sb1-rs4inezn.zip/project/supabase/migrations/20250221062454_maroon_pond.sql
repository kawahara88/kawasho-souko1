/*
  # Update storage fees table

  This migration updates the storage fees table to better handle period-based calculations.

  1. Changes
    - Add period number column to track which period the fee belongs to (1, 2, or 3)
    - Add ending stock column to track stock at period end
    - Add inbound quantity column to track period inbound quantity
    - Add stock cubic meters column for fee calculation base
*/

-- Add new columns to storage_fees table if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'storage_fees' AND column_name = 'period_number'
  ) THEN
    ALTER TABLE storage_fees ADD COLUMN period_number integer NOT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'storage_fees' AND column_name = 'ending_stock'
  ) THEN
    ALTER TABLE storage_fees ADD COLUMN ending_stock integer NOT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'storage_fees' AND column_name = 'inbound_quantity'
  ) THEN
    ALTER TABLE storage_fees ADD COLUMN inbound_quantity integer NOT NULL;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'storage_fees' AND column_name = 'stock_cubic_meters'
  ) THEN
    ALTER TABLE storage_fees ADD COLUMN stock_cubic_meters numeric NOT NULL;
  END IF;
END $$;