import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Navigate, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { Package, PackagePlus, List, BarChart3, History, Calculator, LogOut } from 'lucide-react';
import StockMovement from './pages/StockMovement';
import StockList from './pages/StockList';
import ItemRegistration from './pages/ItemRegistration';
import ItemList from './pages/ItemList';
import StockMovementHistory from './pages/StockMovementHistory';
import StorageFees from './pages/StorageFees';
import Login from './pages/Login';
import ProtectedRoute from './components/ProtectedRoute';
import { useAuth } from './hooks/useAuth';

function NavLink({ to, icon: Icon, children }: { to: string; icon: React.ElementType; children: React.ReactNode }) {
  const location = useLocation();
  const isActive = location.pathname === to;

  return (
    <Link
      to={to}
      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors duration-200 group ${
        isActive 
          ? 'bg-indigo-50 text-indigo-700' 
          : 'text-gray-700 hover:bg-indigo-50 hover:text-indigo-700'
      }`}
    >
      <Icon className={`h-5 w-5 ${isActive ? 'text-indigo-600' : 'text-gray-400 group-hover:text-indigo-600'}`} />
      <span className="font-medium">{children}</span>
    </Link>
  );
}

function AppContent() {
  const { logout } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Side Navigation */}
      <nav className="fixed top-0 left-0 h-full w-64 bg-white shadow-lg z-30">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <div className="bg-indigo-100 p-2 rounded-lg">
              <Package className="h-8 w-8 text-indigo-600" />
            </div>
            <span className="text-xl font-bold text-gray-900">在庫管理</span>
          </div>
          
          <div className="space-y-1">
            <NavLink to="/" icon={Package}>
              入出庫管理
            </NavLink>
            
            <NavLink to="/history" icon={History}>
              入出庫履歴
            </NavLink>
            
            <NavLink to="/stock" icon={BarChart3}>
              在庫一覧
            </NavLink>
            
            <NavLink to="/items/new" icon={PackagePlus}>
              アイテム登録
            </NavLink>
            
            <NavLink to="/items" icon={List}>
              アイテム一覧
            </NavLink>

            <NavLink to="/fees" icon={Calculator}>
              倉庫管理
            </NavLink>

            <button
              onClick={logout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors duration-200 text-gray-700 hover:bg-red-50 hover:text-red-700 group"
            >
              <LogOut className="h-5 w-5 text-gray-400 group-hover:text-red-600" />
              <span className="font-medium">ログアウト</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="ml-64 p-8">
        <div className="max-w-[1600px] mx-auto">
          <Routes>
            <Route path="/" element={<StockMovement />} />
            <Route path="/history" element={<StockMovementHistory />} />
            <Route path="/stock" element={<StockList />} />
            <Route path="/items/new" element={<ItemRegistration />} />
            <Route path="/items" element={<ItemList />} />
            <Route 
              path="/fees" 
              element={
                <ProtectedRoute requiredPermission="storage_fees">
                  <StorageFees />
                </ProtectedRoute>
              } 
            />
            <Route path="/login" element={<Login />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <AppContent />
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: {
            background: '#fff',
            color: '#363636',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
            borderRadius: '0.5rem',
            padding: '1rem',
          },
          success: {
            iconTheme: {
              primary: '#4F46E5',
              secondary: '#fff',
            },
          },
          error: {
            iconTheme: {
              primary: '#EF4444',
              secondary: '#fff',
            },
          },
        }}
      />
    </Router>
  );
}