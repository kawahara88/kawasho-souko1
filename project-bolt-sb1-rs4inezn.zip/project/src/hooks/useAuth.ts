import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AuthState {
  isAuthenticated: boolean;
  permissions: string[];
  login: (password: string) => Promise<boolean>;
  logout: () => void;
  hasPermission: (permission: string) => boolean;
}

export const useAuth = create<AuthState>()(
  persist(
    (set, get) => ({
      isAuthenticated: false,
      permissions: [],
      login: async (password: string) => {
        if (password === '1592') {
          set({ isAuthenticated: true, permissions: ['storage_fees'] });
          return true;
        }
        return false;
      },
      logout: () => {
        set({ isAuthenticated: false, permissions: [] });
      },
      hasPermission: (permission: string) => {
        return get().permissions.includes(permission);
      }
    }),
    {
      name: 'auth-storage'
    }
  )
);