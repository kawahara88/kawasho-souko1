import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { supabase } from '../lib/supabase';
import type { Item } from '../types';

export default function ItemRegistration() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    color: '',
    size: '',
    pieces_per_case: '',
    width: '',
    depth: '',
    height: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [existingItems, setExistingItems] = useState<Item[]>([]);
  const [isDuplicate, setIsDuplicate] = useState(false);

  useEffect(() => {
    fetchExistingItems();
  }, []);

  const fetchExistingItems = async () => {
    const { data, error } = await supabase
      .from('items')
      .select('*')
      .order('name, color, size');

    if (error) {
      console.error('Error fetching items:', error);
      return;
    }

    setExistingItems(data || []);
  };

  const calculateCubicMeters = () => {
    const { width, depth, height } = formData;
    if (width && depth && height) {
      return (parseFloat(width) * parseFloat(depth) * parseFloat(height)) / 2700 / 10000;
    }
    return 0;
  };

  const checkDuplicate = () => {
    const trimmedData = {
      name: formData.name.trim(),
      color: formData.color.trim(),
      size: formData.size.trim()
    };

    // Find exact matches (case-insensitive)
    const exactMatch = existingItems.find(item => 
      item.name.toLowerCase() === trimmedData.name.toLowerCase() &&
      item.color.toLowerCase() === trimmedData.color.toLowerCase() &&
      item.size.toLowerCase() === trimmedData.size.toLowerCase()
    );

    if (exactMatch) {
      toast.error('同じアイテム名、カラー、サイズの組み合わせが既に存在します', {
        duration: 5000,
      });
      return true;
    }

    // Find similar items for warning
    const similarItems = existingItems.filter(item =>
      item.name.toLowerCase() === trimmedData.name.toLowerCase() &&
      (
        item.color.toLowerCase() === trimmedData.color.toLowerCase() ||
        item.size.toLowerCase() === trimmedData.size.toLowerCase()
      )
    );

    if (similarItems.length > 0) {
      const result = window.confirm(
        '類似のアイテムが見つかりました:\n\n' +
        similarItems.map(item => 
          `- ${item.name} / ${item.color} / ${item.size}`
        ).join('\n') +
        '\n\n本当に新しいアイテムとして登録しますか？'
      );
      return !result;
    }

    return false;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    try {
      const requiredFields = ['name', 'color', 'size', 'pieces_per_case', 'width', 'depth', 'height'];
      const emptyFields = requiredFields.filter(field => !formData[field as keyof typeof formData].trim());
      
      if (emptyFields.length > 0) {
        toast.error('必須項目をすべて入力してください');
        return;
      }

      if (checkDuplicate()) {
        return;
      }

      setIsSubmitting(true);
      const cubic_meters = calculateCubicMeters();

      const { error } = await supabase
        .from('items')
        .insert({
          name: formData.name.trim(),
          color: formData.color.trim(),
          size: formData.size.trim(),
          pieces_per_case: parseInt(formData.pieces_per_case),
          width: parseFloat(formData.width),
          depth: parseFloat(formData.depth),
          height: parseFloat(formData.height),
          cubic_meters
        });

      if (error) {
        if (error.code === '23505') {
          toast.error('同じアイテム名、カラー、サイズの組み合わせが既に存在します');
        } else {
          toast.error('アイテムの登録に失敗しました');
        }
        return;
      }

      toast.success('アイテムを登録しました');
      navigate('/items');
    } catch (error) {
      toast.error('エラーが発生しました');
      console.error('Error submitting form:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Reset duplicate flag when form changes
    setIsDuplicate(false);
  };

  return (
    <div className="bg-white shadow rounded-lg p-6 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">アイテム登録</h2>
      
      <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-6">
        {/* Left Column */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">アイテム名</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              placeholder="例: Tシャツ"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">カラー/PoNo.</label>
            <input
              type="text"
              name="color"
              value={formData.color}
              onChange={handleChange}
              required
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              placeholder="例: ホワイト"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">サイズ</label>
            <input
              type="text"
              name="size"
              value={formData.size}
              onChange={handleChange}
              required
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              placeholder="例: M"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">入数 (ピース/ケース)</label>
            <input
              type="number"
              name="pieces_per_case"
              value={formData.pieces_per_case}
              onChange={handleChange}
              required
              min="1"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              placeholder="例: 10"
            />
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">幅 (mm)</label>
              <input
                type="number"
                name="width"
                value={formData.width}
                onChange={handleChange}
                required
                min="0"
                step="0.1"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                placeholder="例: 300"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">奥行 (mm)</label>
              <input
                type="number"
                name="depth"
                value={formData.depth}
                onChange={handleChange}
                required
                min="0"
                step="0.1"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                placeholder="例: 200"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">高さ (mm)</label>
              <input
                type="number"
                name="height"
                value={formData.height}
                onChange={handleChange}
                required
                min="0"
                step="0.1"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                placeholder="例: 50"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">才数</label>
            <div className="mt-1 block w-full rounded-md border border-gray-300 bg-gray-50 px-3 py-2">
              {calculateCubicMeters().toFixed(3)} 才
            </div>
          </div>

          <div className="pt-4">
            <button
              type="submit"
              disabled={isSubmitting || isDuplicate}
              className={`w-full flex justify-center items-center gap-2 py-2.5 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${
                (isSubmitting || isDuplicate) ? 'opacity-75 cursor-not-allowed' : ''
              }`}
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>登録中...</span>
                </>
              ) : (
                'このアイテムを登録する'
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}