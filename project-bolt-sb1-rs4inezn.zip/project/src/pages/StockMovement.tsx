import React, { useState, useEffect, useMemo } from 'react';
import DatePicker from 'react-datepicker';
import { format } from 'date-fns';
import { ja } from 'date-fns/locale';
import toast from 'react-hot-toast';
import { Package, ArrowDownCircle, ArrowUpCircle, Search } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Item } from '../types';
import "react-datepicker/dist/react-datepicker.css";

function MovementTypeButton({ type, selected, onClick }: { type: 'in' | 'out', selected: boolean, onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg border-2 transition-all duration-200 ${
        selected 
          ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-sm' 
          : 'border-gray-200 hover:border-indigo-200 hover:bg-indigo-50'
      }`}
    >
      {type === 'in' ? (
        <>
          <ArrowDownCircle className={`h-4 w-4 ${selected ? 'text-indigo-600' : 'text-gray-400'}`} />
          <span className="font-medium text-sm">入庫</span>
        </>
      ) : (
        <>
          <ArrowUpCircle className={`h-4 w-4 ${selected ? 'text-indigo-600' : 'text-gray-400'}`} />
          <span className="font-medium text-sm">出庫</span>
        </>
      )}
    </button>
  );
}

function QuantityTypeButton({ type, selected, onClick }: { type: 'case' | 'piece', selected: boolean, onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg border-2 transition-all duration-200 ${
        selected 
          ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-sm' 
          : 'border-gray-200 hover:border-indigo-200 hover:bg-indigo-50'
      }`}
    >
      <Package className={`h-4 w-4 ${selected ? 'text-indigo-600' : 'text-gray-400'}`} />
      <span className="font-medium text-sm">{type === 'case' ? 'ケース単位' : 'ピース単位'}</span>
    </button>
  );
}

interface AutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  onSelect: (value: string) => void;
  suggestions: string[];
  placeholder: string;
  label: string;
  disabled?: boolean;
}

function Autocomplete({ value, onChange, onSelect, suggestions, placeholder, label, disabled = false }: AutocompleteProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);

  const filteredSuggestions = useMemo(() => {
    if (!value.trim()) return suggestions;
    const searchTerm = value.toLowerCase();
    return suggestions.filter(item => 
      item.toLowerCase().includes(searchTerm)
    );
  }, [value, suggestions]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightedIndex(prev => 
        prev < filteredSuggestions.length - 1 ? prev + 1 : prev
      );
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightedIndex(prev => prev > 0 ? prev - 1 : prev);
    } else if (e.key === 'Enter' && highlightedIndex >= 0) {
      e.preventDefault();
      onSelect(filteredSuggestions[highlightedIndex]);
      setIsOpen(false);
    } else if (e.key === 'Escape') {
      setIsOpen(false);
    }
  };

  return (
    <div className="relative">
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <div className="relative">
        <input
          type="text"
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            setIsOpen(true);
            setHighlightedIndex(-1);
          }}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2.5 disabled:bg-gray-100"
          placeholder={placeholder}
        />
        <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
      </div>
      {isOpen && filteredSuggestions.length > 0 && (
        <div className="absolute z-10 w-full mt-1 bg-white shadow-lg max-h-60 rounded-md py-1 text-base overflow-auto focus:outline-none sm:text-sm">
          {filteredSuggestions.map((suggestion, index) => (
            <div
              key={suggestion}
              className={`cursor-pointer select-none relative py-2 pl-3 pr-9 ${
                index === highlightedIndex ? 'bg-indigo-50 text-indigo-900' : 'text-gray-900'
              }`}
              onClick={() => {
                onSelect(suggestion);
                setIsOpen(false);
              }}
              onMouseEnter={() => setHighlightedIndex(index)}
            >
              {suggestion}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function StockMovement() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [items, setItems] = useState<Item[]>([]);
  const [itemNameInput, setItemNameInput] = useState('');
  const [colorInput, setColorInput] = useState('');
  const [selectedItem, setSelectedItem] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [movementType, setMovementType] = useState<'in' | 'out'>('in');
  const [quantityType, setQuantityType] = useState<'case' | 'piece'>('case');
  const [quantity, setQuantity] = useState(0);
  const [availableColors, setAvailableColors] = useState<string[]>([]);
  const [availableSizes, setAvailableSizes] = useState<string[]>([]);
  const [selectedItemData, setSelectedItemData] = useState<Item | null>(null);
  const [calculatedPieces, setCalculatedPieces] = useState<number>(0);
  const [currentStock, setCurrentStock] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    const { data, error } = await supabase
      .from('items')
      .select('*')
      .order('name');
    
    if (error) {
      toast.error('アイテムの取得に失敗しました');
      return;
    }

    setItems(data);
  };

  const uniqueItemNames = useMemo(() => 
    [...new Set(items.map(item => item.name))],
    [items]
  );

  useEffect(() => {
    if (selectedItem) {
      const colors = [...new Set(items
        .filter(item => item.name === selectedItem)
        .map(item => item.color))];
      setAvailableColors(colors);
      setSelectedColor('');
      setSelectedSize('');
      setColorInput('');
    } else {
      setAvailableColors([]);
    }
  }, [selectedItem, items]);

  useEffect(() => {
    if (selectedItem && selectedColor) {
      const sizes = [...new Set(items
        .filter(item => item.name === selectedItem && item.color === selectedColor)
        .map(item => item.size))];
      setAvailableSizes(sizes);
      setSelectedSize('');
    } else {
      setAvailableSizes([]);
    }
  }, [selectedColor, selectedItem, items]);

  useEffect(() => {
    if (selectedItem && selectedColor && selectedSize) {
      const itemData = items.find(item => 
        item.name === selectedItem && 
        item.color === selectedColor && 
        item.size === selectedSize
      );
      setSelectedItemData(itemData || null);
      if (itemData) {
        fetchCurrentStock(itemData.id);
        if (quantityType === 'case') {
          setQuantity(1);
          setCalculatedPieces(itemData.pieces_per_case);
        } else {
          setQuantity(0);
          setCalculatedPieces(0);
        }
      }
    } else {
      setSelectedItemData(null);
      setCalculatedPieces(0);
      setCurrentStock(0);
    }
  }, [selectedItem, selectedColor, selectedSize, items, quantityType]);

  const fetchCurrentStock = async (itemId: string) => {
    try {
      const { data, error } = await supabase
        .from('stock')
        .select('total_pieces')
        .eq('item_id', itemId)
        .maybeSingle();

      if (error) {
        console.error('Error fetching stock:', error);
        setCurrentStock(0);
        return;
      }

      setCurrentStock(data?.total_pieces || 0);
    } catch (error) {
      console.error('Error in fetchCurrentStock:', error);
      setCurrentStock(0);
    }
  };

  useEffect(() => {
    if (selectedItemData && quantityType === 'case') {
      setCalculatedPieces(quantity * selectedItemData.pieces_per_case);
    } else if (quantityType === 'piece') {
      setCalculatedPieces(quantity);
    }
  }, [quantity, quantityType, selectedItemData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    if (!selectedItemData) {
      toast.error('アイテムを選択してください');
      return;
    }

    setIsSubmitting(true);
    const finalPieces = calculatedPieces;

    if (movementType === 'out' && finalPieces > currentStock) {
      toast.error('在庫が不足しています');
      setIsSubmitting(false);
      return;
    }

    try {
      // Start a Supabase transaction
      const { data: stockData, error: stockError } = await supabase
        .from('stock')
        .select('*')
        .eq('item_id', selectedItemData.id)
        .maybeSingle();

      if (stockError) {
        throw stockError;
      }

      const newPieces = movementType === 'in' 
        ? (stockData?.total_pieces || 0) + finalPieces
        : (stockData?.total_pieces || 0) - finalPieces;

      // Check for negative stock
      if (newPieces < 0) {
        const result = confirm(
          `警告: この操作により在庫数がマイナスになります。\n\n` +
          `現在の在庫数: ${currentStock.toLocaleString()} ピース\n` +
          `${movementType === 'in' ? '入庫' : '出庫'}数: ${finalPieces.toLocaleString()} ピース\n` +
          `操作後の在庫数: ${newPieces.toLocaleString()} ピース\n\n` +
          `本当に続行しますか？`
        );
        
        if (!result) {
          setIsSubmitting(false);
          return;
        }
      }

      // Insert stock movement with original quantity
      const { error: movementError } = await supabase
        .from('stock_movements')
        .insert({
          item_id: selectedItemData.id,
          movement_date: format(selectedDate, 'yyyy-MM-dd'),
          movement_type: movementType,
          quantity_type: quantityType,
          quantity: quantity
        });

      if (movementError) {
        throw movementError;
      }

      // Update or insert stock record
      if (stockData) {
        const { error: updateError } = await supabase
          .from('stock')
          .update({ 
            total_pieces: newPieces,
            updated_at: new Date().toISOString()
          })
          .eq('item_id', selectedItemData.id);

        if (updateError) {
          throw updateError;
        }
      } else {
        const { error: insertError } = await supabase
          .from('stock')
          .insert({
            item_id: selectedItemData.id,
            total_pieces: newPieces,
            updated_at: new Date().toISOString()
          });

        if (insertError) {
          throw insertError;
        }
      }

      toast.success('在庫移動を登録しました');
      
      setSelectedItem('');
      setSelectedColor('');
      setSelectedSize('');
      setQuantity(0);
      setCalculatedPieces(0);
      setCurrentStock(0);
      setItemNameInput('');
      setColorInput('');
    } catch (error) {
      console.error('Error in handleSubmit:', error);
      toast.error('エラーが発生しました');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white shadow rounded-lg p-6 max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">入出庫管理</h2>
      
      <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-6">
        {/* Left Column */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">入出庫日</label>
            <DatePicker
              selected={selectedDate}
              onChange={(date: Date) => setSelectedDate(date)}
              locale={ja}
              dateFormat="yyyy/MM/dd"
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2 px-3"
            />
          </div>

          <div className="space-y-4 bg-gray-50 p-4 rounded-lg">
            <Autocomplete
              value={itemNameInput}
              onChange={setItemNameInput}
              onSelect={(value) => {
                setItemNameInput(value);
                setSelectedItem(value);
              }}
              suggestions={uniqueItemNames}
              placeholder="アイテム名を入力または選択"
              label="アイテム名"
            />

            <Autocomplete
              value={colorInput}
              onChange={setColorInput}
              onSelect={(value) => {
                setColorInput(value);
                setSelectedColor(value);
              }}
              suggestions={availableColors}
              placeholder="カラー/PoNo.を入力または選択"
              label="カラー/PoNo."
              disabled={!selectedItem}
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">サイズ</label>
              <select
                value={selectedSize}
                onChange={(e) => setSelectedSize(e.target.value)}
                disabled={!selectedColor}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2.5 disabled:bg-gray-100"
              >
                <option value="">選択してください</option>
                {availableSizes.map(size => (
                  <option key={size} value={size}>{size}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">入出庫タイプ</label>
            <div className="flex gap-2">
              <MovementTypeButton
                type="in"
                selected={movementType === 'in'}
                onClick={() => setMovementType('in')}
              />
              <MovementTypeButton
                type="out"
                selected={movementType === 'out'}
                onClick={() => setMovementType('out')}
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">数量タイプ</label>
            <div className="flex gap-2">
              <QuantityTypeButton
                type="case"
                selected={quantityType === 'case'}
                onClick={() => {
                  setQuantityType('case');
                  if (selectedItemData) {
                    setQuantity(1);
                    setCalculatedPieces(selectedItemData.pieces_per_case);
                  }
                }}
              />
              <QuantityTypeButton
                type="piece"
                selected={quantityType === 'piece'}
                onClick={() => {
                  setQuantityType('piece');
                  setQuantity(0);
                  setCalculatedPieces(0);
                }}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              数量 {quantityType === 'case' ? '(ケース)' : '(ピース)'}
            </label>
            <input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(parseInt(e.target.value) || 0)}
              min="0"
              className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 py-2 px-3"
            />
          </div>

          {selectedItemData && (
            <div className="grid grid-cols-1 gap-2">
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-sm text-gray-700">
                  現在の在庫: <span className="font-medium">{currentStock.toLocaleString()} ピース</span>
                </p>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-sm text-gray-700">
                  {movementType === 'in' ? '入庫' : '出庫'}数: <span className="font-medium">{calculatedPieces.toLocaleString()} ピース</span>
                  {quantityType === 'case' && selectedItemData && (
                    <span className="text-gray-500 text-xs block">
                      ({selectedItemData.pieces_per_case} ピース/ケース × {quantity} ケース)
                    </span>
                  )}
                </p>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className="text-sm text-gray-700">
                  移動後の在庫: <span className="font-medium">
                    {(movementType === 'in' ? currentStock + calculatedPieces : currentStock - calculatedPieces).toLocaleString()} ピース
                  </span>
                </p>
              </div>
            </div>
          )}

          <div>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`w-full flex justify-center items-center gap-2 py-2.5 px-4 border border-transparent rounded-lg shadow-sm text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all duration-200 ${
                isSubmitting ? 'opacity-75 cursor-not-allowed' : ''
              }`}
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>処理中...</span>
                </>
              ) : (
                '確定'
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}