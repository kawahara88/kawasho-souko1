import React, { useState, useEffect } from 'react';
import { Search } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Item, StockMovement } from '../types';

interface StockItem extends Item {
  stock: {
    total_pieces: number;
  };
}

export default function StockList() {
  const [items, setItems] = useState<StockItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [totalCases, setTotalCases] = useState(0);
  const [totalCubicMeters, setTotalCubicMeters] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchStockData();

    // Subscribe to stock changes
    const stockSubscription = supabase
      .channel('stock_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'stock'
        },
        () => {
          fetchStockData();
        }
      )
      .subscribe();

    // Subscribe to stock movement changes
    const movementSubscription = supabase
      .channel('movement_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'stock_movements'
        },
        () => {
          fetchStockData();
        }
      )
      .subscribe();

    return () => {
      stockSubscription.unsubscribe();
      movementSubscription.unsubscribe();
    };
  }, []);

  const fetchStockData = async () => {
    try {
      // First, get all items
      const { data: itemsData, error: itemsError } = await supabase
        .from('items')
        .select('*')
        .order('name, color, size');

      if (itemsError) throw itemsError;

      // Then, get all stock movements that haven't been deleted
      const { data: movementsData, error: movementsError } = await supabase
        .from('stock_movements')
        .select('*')
        .is('deleted_at', null);

      if (movementsError) throw movementsError;

      // Calculate stock for each item based on movements
      const stockItems = itemsData.map(item => {
        // Filter movements for this item
        const itemMovements = movementsData.filter(m => m.item_id === item.id);

        // Calculate total pieces from movements
        const totalPieces = itemMovements.reduce((total, movement) => {
          const pieces = movement.quantity_type === 'case'
            ? movement.quantity * item.pieces_per_case
            : movement.quantity;
          return movement.movement_type === 'in'
            ? total + pieces
            : total - pieces;
        }, 0);

        return {
          ...item,
          stock: {
            total_pieces: totalPieces
          }
        };
      });

      setItems(stockItems);

      // Calculate totals
      const totals = stockItems.reduce((acc, item) => {
        const pieces = item.stock.total_pieces;
        const cases = Math.ceil(pieces / item.pieces_per_case);
        const cubicMeters = cases * item.cubic_meters;

        return {
          cases: acc.cases + cases,
          cubicMeters: acc.cubicMeters + cubicMeters
        };
      }, { cases: 0, cubicMeters: 0 });

      setTotalCases(totals.cases);
      setTotalCubicMeters(totals.cubicMeters);
    } catch (error) {
      console.error('Error in fetchStockData:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredItems = items.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.color.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.size.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-2">総合計ケース数</h3>
          <p className="text-3xl font-bold text-indigo-600">{totalCases.toLocaleString()} ケース</p>
        </div>
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-2">総合計才数</h3>
          <p className="text-3xl font-bold text-indigo-600">{totalCubicMeters.toFixed(3)} 才</p>
        </div>
      </div>

      {/* Stock List */}
      <div className="bg-white shadow rounded-lg">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h2 className="text-2xl font-bold text-gray-900">在庫一覧</h2>
            <div className="relative w-full sm:w-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="アイテム名、カラー、サイズで検索..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full sm:w-96 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">アイテム名</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">カラー/PoNo.</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">サイズ</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">在庫数(ピース)</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">ケース数</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">合計才数</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredItems.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-10 text-center text-gray-500">
                      {searchTerm ? '検索条件に一致するアイテムが見つかりません' : 'アイテムが登録されていません'}
                    </td>
                  </tr>
                ) : (
                  filteredItems.map((item) => {
                    const pieces = item.stock.total_pieces;
                    const cases = Math.ceil(pieces / item.pieces_per_case);
                    const cubicMeters = cases * item.cubic_meters;

                    return (
                      <tr 
                        key={item.id}
                        className="hover:bg-gray-50 transition-colors duration-150"
                      >
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {item.name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {item.color}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {item.size}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-right font-medium text-gray-900">
                          {pieces.toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                          {cases.toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-right text-gray-900">
                          {cubicMeters.toFixed(3)}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}