import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { ja } from 'date-fns/locale';
import DatePicker from 'react-datepicker';
import { Search, ArrowDownCircle, ArrowUpCircle, Package, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { supabase } from '../lib/supabase';
import type { Item, StockMovement } from '../types';

interface MovementWithItem extends StockMovement {
  items: Item;
}

export default function StockMovementHistory() {
  const [movements, setMovements] = useState<MovementWithItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState<Date | null>(new Date());
  const [endDate, setEndDate] = useState<Date | null>(new Date());
  const [isLoading, setIsLoading] = useState(true);
  const [isDeletingId, setIsDeletingId] = useState<string | null>(null);

  useEffect(() => {
    fetchMovements();
  }, [startDate, endDate]);

  const fetchMovements = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('stock_movements')
        .select(`
          *,
          items (*)
        `)
        .is('deleted_at', null)
        .gte('movement_date', startDate ? format(startDate, 'yyyy-MM-dd') : '')
        .lte('movement_date', endDate ? format(endDate, 'yyyy-MM-dd') : '')
        .order('movement_date', { ascending: false })
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching movements:', error);
        return;
      }

      setMovements(data as MovementWithItem[]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (movement: MovementWithItem) => {
    try {
      // Calculate the stock adjustment based on the movement type and quantity
      const adjustmentPieces = movement.quantity_type === 'case'
        ? movement.quantity * movement.items.pieces_per_case
        : movement.quantity;

      const stockAdjustment = movement.movement_type === 'in'
        ? -adjustmentPieces // If it was an inbound movement, we need to subtract
        : adjustmentPieces; // If it was an outbound movement, we need to add back

      // Get current stock
      const { data: stockData, error: stockError } = await supabase
        .from('stock')
        .select('total_pieces')
        .eq('item_id', movement.item_id)
        .single();

      if (stockError) {
        toast.error('在庫データの取得に失敗しました');
        return;
      }

      const currentStock = stockData.total_pieces;
      const newStock = currentStock + stockAdjustment;

      // Check if the deletion would result in negative stock
      if (newStock < 0) {
        const result = confirm(
          `警告: この履歴を削除すると在庫数がマイナスになります。\n\n` +
          `現在の在庫数: ${currentStock.toLocaleString()} ピース\n` +
          `削除後の在庫数: ${newStock.toLocaleString()} ピース\n\n` +
          `本当に削除してもよろしいですか？`
        );
        
        if (!result) {
          return;
        }
      } else {
        if (!confirm('この入出庫履歴を削除してもよろしいですか？\n在庫数が元に戻ります。')) {
          return;
        }
      }

      setIsDeletingId(movement.id);

      // Update stock
      const { error: updateError } = await supabase
        .from('stock')
        .update({ 
          total_pieces: newStock,
          updated_at: new Date().toISOString()
        })
        .eq('item_id', movement.item_id);

      if (updateError) {
        toast.error('在庫の更新に失敗しました');
        return;
      }

      // Soft delete the movement record
      const { error: deleteError } = await supabase
        .from('stock_movements')
        .update({ deleted_at: new Date().toISOString() })
        .eq('id', movement.id);

      if (deleteError) {
        toast.error('履歴の削除に失敗しました');
        return;
      }

      toast.success('履歴を削除し、在庫を更新しました');
      fetchMovements();
    } catch (error) {
      toast.error('エラーが発生しました');
      console.error('Error deleting movement:', error);
    } finally {
      setIsDeletingId(null);
    }
  };

  const filteredMovements = movements.filter(movement =>
    movement.items.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    movement.items.color.toLowerCase().includes(searchTerm.toLowerCase()) ||
    movement.items.size.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getMovementTypeIcon = (type: 'in' | 'out') => {
    return type === 'in' ? (
      <ArrowDownCircle className="h-5 w-5 text-green-600" />
    ) : (
      <ArrowUpCircle className="h-5 w-5 text-red-600" />
    );
  };

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <h2 className="text-2xl font-bold">入出庫履歴</h2>
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex items-center gap-2">
            <DatePicker
              selected={startDate}
              onChange={setStartDate}
              selectsStart
              startDate={startDate}
              endDate={endDate}
              locale={ja}
              dateFormat="yyyy/MM/dd"
              className="rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              placeholderText="開始日"
            />
            <span className="text-gray-500">～</span>
            <DatePicker
              selected={endDate}
              onChange={setEndDate}
              selectsEnd
              startDate={startDate}
              endDate={endDate}
              minDate={startDate}
              locale={ja}
              dateFormat="yyyy/MM/dd"
              className="rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              placeholderText="終了日"
            />
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="アイテム名、カラー、サイズで検索..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">日付</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">タイプ</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">アイテム名</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">カラー/PoNo.</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">サイズ</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">数量</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredMovements.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-10 text-center text-gray-500">
                    {searchTerm ? '検索条件に一致する履歴が見つかりません' : '履歴がありません'}
                  </td>
                </tr>
              ) : (
                filteredMovements.map((movement) => (
                  <tr 
                    key={movement.id} 
                    className={`hover:bg-gray-50 ${movement.deleted_at ? 'opacity-50' : ''}`}
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      {format(new Date(movement.movement_date), 'yyyy/MM/dd')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {getMovementTypeIcon(movement.movement_type)}
                        <span className={`ml-2 ${
                          movement.movement_type === 'in' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {movement.movement_type === 'in' ? '入庫' : '出庫'}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">{movement.items.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{movement.items.color}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{movement.items.size}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <div className="flex items-center justify-end gap-1">
                        <span className="font-medium">{movement.quantity.toLocaleString()}</span>
                        <span className="text-gray-500">
                          {movement.quantity_type === 'case' ? 'ケース' : 'ピース'}
                        </span>
                      </div>
                      {movement.quantity_type === 'case' && (
                        <div className="text-sm text-gray-500">
                          ({(movement.quantity * movement.items.pieces_per_case).toLocaleString()} ピース)
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      {!movement.deleted_at && (
                        <button
                          onClick={() => handleDelete(movement)}
                          disabled={isDeletingId === movement.id}
                          className={`text-red-600 hover:text-red-900 transition-colors duration-200 ${
                            isDeletingId === movement.id ? 'opacity-50 cursor-not-allowed' : ''
                          }`}
                        >
                          {isDeletingId === movement.id ? (
                            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-red-600"></div>
                          ) : (
                            <Trash2 className="h-5 w-5" />
                          )}
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}