import React, { useState, useEffect } from 'react';
import { format, endOfMonth, startOfMonth, addDays, isWithinInterval, subMonths, isBefore, parseISO } from 'date-fns';
import { ja } from 'date-fns/locale';
import DatePicker from 'react-datepicker';
import { Search } from 'lucide-react';
import toast from 'react-hot-toast';
import { supabase } from '../lib/supabase';
import type { Item, StockMovement } from '../types';

const STORAGE_FEE_PER_CUBIC_METER = 12;
const INBOUND_FEE_PER_CUBIC_METER = 12;
const OUTBOUND_FEE_PER_CUBIC_METER = 12;
const STORAGE_START_DATE = parseISO('2025-02-11'); // 2025年2月11日から保管開始

interface PeriodFees {
  period: number;
  startDate: Date;
  endDate: Date;
  endingStock: number;
  inboundQuantity: number;
  stockCubicMeters: number;
  storageFee: number;
}

interface StorageFee {
  item: Item;
  periods: PeriodFees[];
  inboundFee: number;
  outboundFee: number;
  totalFee: number;
}

interface MovementWithCaseChange {
  movement: StockMovement;
  casesChanged: number;
}

export default function StorageFees() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [searchTerm, setSearchTerm] = useState('');
  const [storageFees, setStorageFees] = useState<StorageFee[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [totalFees, setTotalFees] = useState({
    storage: 0,
    inbound: 0,
    outbound: 0,
    total: 0
  });

  useEffect(() => {
    calculateFees();
  }, [selectedDate]);

  const getPeriodDates = (date: Date) => {
    const monthStart = startOfMonth(date);
    return [
      {
        period: 1,
        start: monthStart,
        end: addDays(monthStart, 9)
      },
      {
        period: 2,
        start: addDays(monthStart, 10),
        end: addDays(monthStart, 19)
      },
      {
        period: 3,
        start: addDays(monthStart, 20),
        end: endOfMonth(date)
      }
    ];
  };

  const calculateStockAtDate = (
    movements: StockMovement[],
    item: Item,
    targetDate: Date,
    currentStock: number
  ) => {
    // 2025年2月11日より前は在庫0固定
    if (isBefore(targetDate, STORAGE_START_DATE)) {
      return 0;
    }

    // Filter movements up to the target date
    const relevantMovements = movements
      .filter(m => 
        m.item_id === item.id && 
        !m.deleted_at &&
        new Date(m.movement_date) <= targetDate &&
        !isBefore(new Date(m.movement_date), STORAGE_START_DATE) // 2025年2月11日以降の移動のみ考慮
      )
      .sort((a, b) => new Date(a.movement_date).getTime() - new Date(b.movement_date).getTime());

    // Calculate stock by applying movements in chronological order
    return relevantMovements.reduce((stock, movement) => {
      const quantity = movement.quantity_type === 'case'
        ? movement.quantity * item.pieces_per_case
        : movement.quantity;
      return movement.movement_type === 'in' ? stock + quantity : stock - quantity;
    }, 0); // Start from 0 instead of currentStock to calculate historical stock accurately
  };

  const calculateCaseChanges = (
    movements: StockMovement[],
    item: Item,
    initialStock: number
  ): MovementWithCaseChange[] => {
    let runningStock = initialStock;
    const result: MovementWithCaseChange[] = [];

    for (const movement of movements) {
      const pieces = movement.quantity_type === 'case'
        ? movement.quantity * item.pieces_per_case
        : movement.quantity;

      const oldCases = Math.ceil(runningStock / item.pieces_per_case);
      const newStock = movement.movement_type === 'in'
        ? runningStock + pieces
        : runningStock - pieces;
      const newCases = Math.ceil(newStock / item.pieces_per_case);
      const casesChanged = Math.abs(newCases - oldCases);

      if (casesChanged > 0) {
        result.push({
          movement,
          casesChanged
        });
      }

      runningStock = newStock;
    }

    return result;
  };

  const calculateFees = async () => {
    setIsLoading(true);
    try {
      const periodDates = getPeriodDates(selectedDate);
      const monthStart = startOfMonth(selectedDate);
      const monthEnd = endOfMonth(selectedDate);
      const previousMonthEnd = endOfMonth(subMonths(selectedDate, 1));

      // Get all items
      const { data: items, error: itemsError } = await supabase
        .from('items')
        .select('*');

      if (itemsError) throw itemsError;

      // Get stock movements including previous month
      const { data: movements, error: movementsError } = await supabase
        .from('stock_movements')
        .select('*')
        .lte('movement_date', format(monthEnd, 'yyyy-MM-dd'))
        .order('movement_date');

      if (movementsError) throw movementsError;

      // Calculate fees for each item
      const fees = await Promise.all(items.map(async (item) => {
        // Calculate stock at the end of previous month
        const previousMonthEndStock = calculateStockAtDate(
          movements,
          item,
          previousMonthEnd,
          0 // Start from 0 to calculate historical stock accurately
        );

        // Get movements for the current month only
        const itemMovements = movements.filter(m => 
          m.item_id === item.id &&
          !m.deleted_at &&
          isWithinInterval(new Date(m.movement_date), {
            start: monthStart,
            end: monthEnd
          })
        );

        let previousPeriodEndingStock = previousMonthEndStock;

        // Calculate period fees
        const periodFees = periodDates.map((period) => {
          // Get movements within this period
          const periodMovements = itemMovements.filter(m => 
            isWithinInterval(new Date(m.movement_date), {
              start: period.start,
              end: period.end
            })
          );

          // Calculate inbound quantity for this period
          const periodInbound = periodMovements
            .filter(m => m.movement_type === 'in')
            .reduce((acc, m) => acc + (
              m.quantity_type === 'case' 
                ? m.quantity * item.pieces_per_case 
                : m.quantity
            ), 0);

          // Calculate outbound quantity for this period
          const periodOutbound = periodMovements
            .filter(m => m.movement_type === 'out')
            .reduce((acc, m) => acc + (
              m.quantity_type === 'case' 
                ? m.quantity * item.pieces_per_case 
                : m.quantity
            ), 0);

          // Calculate stock for fee calculation
          let stockForFee = previousPeriodEndingStock + periodInbound;

          // 2025年2月11日より前の期間は在庫0固定
          if (isBefore(period.end, STORAGE_START_DATE)) {
            stockForFee = 0;
          }

          const stockCases = Math.ceil(stockForFee / item.pieces_per_case);
          const stockCubicMeters = stockCases * item.cubic_meters;

          // Calculate ending stock for this period
          const endingStock = stockForFee - periodOutbound;
          previousPeriodEndingStock = endingStock;

          return {
            period: period.period,
            startDate: period.start,
            endDate: period.end,
            endingStock,
            inboundQuantity: periodInbound,
            stockCubicMeters,
            storageFee: stockCubicMeters * STORAGE_FEE_PER_CUBIC_METER
          };
        });

        // Calculate case changes for inbound/outbound fees
        const caseChanges = calculateCaseChanges(itemMovements, item, previousMonthEndStock);

        // Calculate inbound/outbound fees based on case changes
        const inboundFee = caseChanges
          .filter(change => change.movement.movement_type === 'in')
          .reduce((acc, change) => acc + (change.casesChanged * item.cubic_meters * INBOUND_FEE_PER_CUBIC_METER), 0);

        const outboundFee = caseChanges
          .filter(change => change.movement.movement_type === 'out')
          .reduce((acc, change) => acc + (change.casesChanged * item.cubic_meters * OUTBOUND_FEE_PER_CUBIC_METER), 0);

        const totalStorageFee = periodFees.reduce((acc, period) => acc + period.storageFee, 0);

        return {
          item,
          periods: periodFees,
          inboundFee,
          outboundFee,
          totalFee: totalStorageFee + inboundFee + outboundFee
        };
      }));

      // Calculate totals
      const totals = fees.reduce((acc, fee) => ({
        storage: acc.storage + fee.periods.reduce((sum, p) => sum + p.storageFee, 0),
        inbound: acc.inbound + fee.inboundFee,
        outbound: acc.outbound + fee.outboundFee,
        total: acc.total + fee.totalFee
      }), { storage: 0, inbound: 0, outbound: 0, total: 0 });

      setStorageFees(fees);
      setTotalFees(totals);
    } catch (error) {
      console.error('Error calculating fees:', error);
      toast.error('料金の計算中にエラーが発生しました');
    } finally {
      setIsLoading(false);
    }
  };

  const filteredFees = storageFees.filter(fee =>
    fee.item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    fee.item.color.toLowerCase().includes(searchTerm.toLowerCase()) ||
    fee.item.size.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h2 className="text-2xl font-bold">倉庫管理</h2>
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <DatePicker
              selected={selectedDate}
              onChange={setSelectedDate}
              dateFormat="yyyy年MM月"
              showMonthYearPicker
              locale={ja}
              className="rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
            
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="検索..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-indigo-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">保管料合計</p>
            <p className="text-xl font-bold text-indigo-600">¥{totalFees.storage.toLocaleString()}</p>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">入庫料合計</p>
            <p className="text-xl font-bold text-green-600">¥{totalFees.inbound.toLocaleString()}</p>
            <p className="text-xs text-gray-500 mt-1">※ケース数の増加時</p>
          </div>
          <div className="bg-red-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">出庫料合計</p>
            <p className="text-xl font-bold text-red-600">¥{totalFees.outbound.toLocaleString()}</p>
            <p className="text-xs text-gray-500 mt-1">※ケース数の減少時</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">総合計</p>
            <p className="text-xl font-bold">¥{totalFees.total.toLocaleString()}</p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">アイテム名</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">カラー/PoNo.</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">サイズ</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    第一期保管料<br/>(1日～10日)
                    <div className="text-[10px] font-normal text-gray-400 normal-case">前月末在庫 × 12円/才</div>
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    第二期保管料<br/>(11日～20日)
                    <div className="text-[10px] font-normal text-gray-400 normal-case">第一期末在庫 + 入庫数 × 12円/才</div>
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    第三期保管料<br/>(21日～末日)
                    <div className="text-[10px] font-normal text-gray-400 normal-case">第二期末在庫 + 入庫数 × 12円/才</div>
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    入庫料<br/>
                    <div className="text-[10px] font-normal text-gray-400 normal-case">ケース数増加時</div>
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    出庫料<br/>
                    <div className="text-[10px] font-normal text-gray-400 normal-case">ケース数減少時</div>
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">合計</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredFees.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="px-6 py-10 text-center text-gray-500">
                      {searchTerm ? '検索条件に一致するアイテムが見つかりません' : 'アイテムが登録されていません'}
                    </td>
                  </tr>
                ) : (
                  filteredFees.map((fee) => (
                    <tr key={fee.item.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">{fee.item.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap">{fee.item.color}</td>
                      <td className="px-6 py-4 whitespace-nowrap">{fee.item.size}</td>
                      {fee.periods.map((period, index) => (
                        <td key={index} className="px-6 py-4 whitespace-nowrap text-right">
                          <div>¥{period.storageFee.toLocaleString()}</div>
                          <div className="text-xs text-gray-500">
                            ({period.stockCubicMeters.toFixed(3)} 才)
                          </div>
                        </td>
                      ))}
                      <td className="px-6 py-4 whitespace-nowrap text-right">¥{fee.inboundFee.toLocaleString()}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">¥{fee.outboundFee.toLocaleString()}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-right font-medium">¥{fee.totalFee.toLocaleString()}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}