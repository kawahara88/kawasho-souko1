export interface Item {
  id: string;
  name: string;
  color: string;
  size: string;
  pieces_per_case: number;
  width: number;
  depth: number;
  height: number;
  cubic_meters: number;
  lot_number: string | null;
  created_at: string;
}

export interface StockMovement {
  id: string;
  item_id: string;
  movement_date: string;
  movement_type: 'in' | 'out';
  quantity_type: 'case' | 'piece';
  quantity: number;
  lot_number: string | null;
  created_at: string;
  deleted_at: string | null;
}

export interface Stock {
  id: string;
  item_id: string;
  total_pieces: number;
  updated_at: string;
}